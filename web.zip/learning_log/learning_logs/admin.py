from django.contrib import admin
from learning_logs.models import Topic,Entry

admin.site.register(Topic)  #注册主题，使其在界面显示
admin.site.register(Entry)  #注册条目，使其在界面显示

admin.site.site_title = "系统后台"
admin.site.site_header = "学习管理"
admin.site.index_title = "后台管理"