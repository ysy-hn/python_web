from django.db import models
from django.contrib.auth.models import User

class Topic(models.Model):
    """用户学习主题"""
    text = models.CharField(max_length = 200)
    date_added = models.DateTimeField(auto_now_add=True)
    owner = models.ForeignKey(User,on_delete=models.CASCADE)

    def __str__(self):  #返回一个漂亮的、人类可读的模型表示，例如：显示主题名，而不是主题id
        return self.text

class Entry(models.Model):
    """条目主题内容"""
    topic = models.ForeignKey(Topic,on_delete=models.CASCADE)  #ForeignKey多对一表单
    text = models.TextField()
    date_added = models.DateTimeField(auto_now_add=True)

    class Meta:  # Meta存储用于管理模型的额外信息,简单的表示就是显示对外主题名称
        verbose_name_plural = 'entries'

    def __str__(self):
        return self.text[:50] + "..."