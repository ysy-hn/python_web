from django.shortcuts import render
from django.http import HttpResponseRedirect,Http404
from django.urls import reverse
from .models import Topic,Entry
from .forms import TopicForm,EntryForm
from django.contrib.auth.decorators import login_required

def index(request):
    """学习笔记的主页"""
    return render(request, 'learning_logs/index.html')
"""将给定的模板与给定的上下文字典结合在一起，并以渲染的文本返回一个HttpResponse对象，
具体参数属性可见 Django 便捷函数文档"""

@login_required  # 先运行login_required：检查是否已登录，未登录重定向到登录页面,还需在settings中配置重定向的位置
def topics(request):
    """展示所有主题."""
    topics = Topic.objects.filter(owner=request.user).order_by('date_added')
    """order_by():通过括号内的参数来排序，-号表示降序"""
    context = {'topics': topics}
    return render(request, 'learning_logs/topics.html', context)

@login_required
def topic(request,topic_id):  #接受正则表达式(?P<topic_id>\d+)捕获的值，并将其存储到topic_id中。
    """显示单个主题及其所有的条目"""
    topic = Topic.objects.get(id=topic_id)  #通过get获取指定的主题
    # 确认请求的主题属于当前用户
    if topic.owner != request.user:
        raise Http404
    entries = topic.entry_set.order_by('-date_added')#entry_set：获取条目
    context = {'topic': topic, 'entries': entries}
    return render(request, 'learning_logs/topic.html', context)

@login_required
def new_topic(request):
    if request.method != 'POST':
#只是从服务器读取数据的页面，使用GET请求；在用户需要通过表单提交信息时，通常使用POST请求。
        form = TopicForm()
#TopicForm：简单的认为是一个主题表单实例，类似a = b中的b。
    else:
        form = TopicForm(request.POST)
#使用用户输入的数据（它们存储在request.POST中）创建一个TopicForm实例，这样对象form将包含用户提交的信息。
        if form.is_valid():
#is_valid()：核实用户填写了所有必不可少的字段（表单字段默认都是必不可少的）。
            new_topic = form.save(commit=False)
            new_topic.owner = request.user
            new_topic.save()
            return HttpResponseRedirect(reverse('learning_logs:topics'))
#reverse：获取页面url并传递，HttpResponseRedirect：跳转到相应页面。
    context = {'form': form}
#一个大量文本框，内容传递给render渲染上下文。
    return render(request, 'learning_logs/new_topic.html', context)

@login_required
def new_entry(request, topic_id):
    topic = Topic.objects.get(id=topic_id)
    if request.method != 'POST':
        form = EntryForm()
    else:
        form = EntryForm(data=request.POST)
        if form.is_valid():
            new_entry = form.save(commit=False)
# commit=False：不将它保存到数据库中，默认True，保存在数据库中。
            new_entry.topic = topic
            new_entry.save()
            return HttpResponseRedirect(reverse('learning_logs:topic',args=[topic_id]))
# 条目在主题里，确定主题名和id两个实参：URL模式的名称；列表args，其中包含要包含在URL中的所有实参。
    context = {'topic': topic, 'form': form}
    return render(request, 'learning_logs/new_entry.html', context)

@login_required
def edit_entry(request, entry_id):
    entry = Entry.objects.get(id=entry_id)
    topic = entry.topic
    if topic.owner != request.user:
        raise Http404
# 第一步：先确定条目id和该条目关联的主题id。
    if request.method != 'POST':
        form = EntryForm(instance=entry)
# 创建一个 EntryForm实例，这个实参让Django创建一个表单；instance=entry：
# 并使用既有条目对象中的信息填充它。用户将看到既有的数据，并能够编辑它们。
    else:
        form = EntryForm(instance=entry, data=request.POST)
# 跟据既有条目对象创建一个表单实例，并根据request.POST中的相关数据对其进行修改。
        if form.is_valid():
# is_valid()：检查表单是否有效，核实用户填写了所有必不可少的字段（表单字段默认都是必不可少的）。
            form.save()
            return HttpResponseRedirect(reverse('learning_logs:topic',args=[topic.id]))
    context = {'entry': entry, 'topic': topic, 'form': form}
    return render(request, 'learning_logs/edit_entry.html', context)
