# from .base import *  # NOQA
#
#
# DEBUG = False
#
# ALLOWED_HOSTS = ['the5fire.com']
#
# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.mysql',
#         'NAME': 'typeidea_db',  # 数据库名
#         'USER': 'root',  # mysql用户名
#         'PASSWORD': '123',  # mysql密码
#         'HOST': '127.0.0.1',
#         'PORT': 3306,
#         'CONN_MAX_AGE': 5 * 60,  # 持久化连接
#         'OPTIONS': {'charset': 'utf8mb4'}  # 用来配置mysqlclient连接
#     }
# }