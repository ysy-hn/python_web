from .base import *  # NOQA
# NOQA的作用是，告诉PEP 8规范工具，这里不需要检测

DEBUG = True
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.mysql',
#         'NAME': 'typeidea_db',  # 数据库名
#         'USER': 'root',  # mysql用户名
#         'PASSWORD': '123',  # mysql密码
#         'HOST': '127.0.0.1',
#         'PORT': 3306,
#         # 'CONN_MAX_AGE': 5 * 60,  # 持久化连接
#         # 'OPTIONS': {'charset': 'utf8mb4'}  # 用来配置mysqlclient连接
#     }
# }


# """增加django-debug-toolbar优化系统分析性能"""
# INSTALLED_APPS += [
#     'debug_toolbar',
# ]
#
# MIDDLEWARE += [
#     'debug_toolbar.middleware.DebugToolbarMiddleware',
# ]

# DEBUG_TOOLBAR_CONFIG = {
#     'JQUERY_URL': 'https://cdn.bootcss.com/jquery/3.3.1/jquery,min.js',
# }

#
# INTERNAL_IPS = ['127.0.0.1', ]


# """增加djdt_flamegraph火焰图分析性能"""
# DEBUG_TOOLBAR_PANELS = [
#     'djdt_flamegraph.FlamegraphPanel',
# ]


# """增加pympler内存占用分析性能"""
# INSTALLED_APPS += [
#     'debug_toolbar',
#     'pympler',
# ]
#
# DEBUG_TOOLBAR_CONFIG = {
#     'JQUERY_URL': 'https://cdn.bootcss.com/jquery/3.3.1/jquery,min.js',
# }
#
# DEBUG_TOOLBAR_PANELS = [
#     'pympler.panels.MemoryPanel',
# ]


# """增加silk优化系统分析性能"""
# INSTALLED_APPS += [
#     'silk',
# ]
#
# MIDDLEWARE += [
#     'silk.middleware.SilkyMiddleware',
# ]

# # 使用Python的内置cProfile分析器
# SILKY_PYTHON_PROFILER = True
#
# # 生成.prof文件，silk产生的程序跟踪记录，详细记录来执行来哪个文件，哪一行，用了多少时间等信息
# SILKY_PYTHON_PROFILER_BINARY = True
#
# # .prof文件保存路径
# SILKY_PYTHON_PROFILER_RESULT_PATH = '/data/profiles/'


